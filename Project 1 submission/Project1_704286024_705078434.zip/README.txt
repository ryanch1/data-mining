Team members: Ryan Chau (704286024), Jake Tsuyemura (705078434)

Code for each question can be run using Jupyter notebook. There is a file reserved for each question. However,
most of the code that is reused is the portion that loads the data, tokenizes the documents, extracts features,
performs the tf-idf transformation, and applies LSI. This is everything before running the actual learning algorithms.
This is done to organize each section and streamline debugging.

Code sections within each notebook are meant to be run in order, and relevant plots or captured data will be
printed out. The output from the last session run should be visible within each notebook, but the code sections
can be rerun to verify functionality.